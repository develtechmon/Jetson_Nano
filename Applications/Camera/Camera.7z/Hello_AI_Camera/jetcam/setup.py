from setuptools import setup, find_packages

setup(
    name='jetcam',
    version='0.0.0',
    description='An easy to use camera interface for NVIDIA Jetson',
    packages=find_packages(),
    install_requires=[
    ],
)
